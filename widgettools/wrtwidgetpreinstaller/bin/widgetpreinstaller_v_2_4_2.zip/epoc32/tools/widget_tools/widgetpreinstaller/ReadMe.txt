Steps:: Place the following under \epoc32\tools\widget_tools\widgetpreinstaller

1)installwidgets.pl
2)browser_access_policy.xml
3)default_widget_icon.png
4)CWRTWebAppRegistry.exe
5)CWRTWebAppRegistry.intermediate.manifest
6)Microsoft.VC80.CRT.manifest
7)msvcp80.dll
8)msvcr80.dll
9)QtCore4.dll
10)QtSql4.dll
11)"sqldrivers" folder
12)png2mbm.exe
