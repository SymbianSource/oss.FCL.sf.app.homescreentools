#include <iostream>
#include <QtCore>
#include <QMap>
#include <QString>
#include <QVariant>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QFileInfo>
#include <QDir>
#include <QTextStream>

using namespace std;

typedef QMap<QString, QVariant> AttributeMap;
const int CurrentDatabaseVersion = 1;

const QString KEY_VALUE_SEPERATOR = ",";
const QString KEY_VALUE_PAIR_SEPERATOR = ";";
static const char DATA_FOLDER[]        = "data";

void encodeDelimiters(QString& inputString)
{
    // encode all "%" chars with "%10"
    inputString.replace(QString("%"), QString("%10"));

    // encode all key value delimiter
    inputString.replace(KEY_VALUE_SEPERATOR, QString("%20"));

    // encode all key value pair delimiter
    inputString.replace(KEY_VALUE_PAIR_SEPERATOR, QString("%30"));
}

QString decodeDelimiters(const QString& inputString)
{
	
		QString outString(inputString);
		
	  // decode all "%10" to "%"
		outString.replace(QString("%10"), QString("%"));

	  // decode all "%40" to " " (space)
		outString.replace(QString("%40"), QString(" "));
		
		// decode all "%apos" to "'"
		outString.replace(QString("%apos"), QString("'"));
		
		// decode all "%amp" to "&"
		outString.replace(QString("%amp"), QString("&"));
		
				// decode all "%lt" to "<"
		outString.replace(QString("%lt"), QString("<"));
		
				// decode all "%gt" to ">"
		outString.replace(QString("%gt"), QString(">"));
		
				// decode all "%quot" to """
		outString.replace(QString("%quot"), QString("\""));
		
		return outString;
}

bool create(const QString& dbPath)
{
    QString sqliteDbPath(dbPath);
    if(!sqliteDbPath.length()){
        sqliteDbPath = "/epoc32/winscw/c/private/200267C0/webapp_registry.db";
        }

    cout << "CWRTWebAppRegistry - sqliteDbPath : "<< sqliteDbPath.toAscii().data() << endl;

    QSqlDatabase db = QSqlDatabase::database("webAppConnection", FALSE);
    if (!db.isValid()) {
        db = QSqlDatabase::addDatabase("QSQLITE", "webAppConnection");
        db.setHostName("WebAppRegistry");
        db.setDatabaseName(sqliteDbPath);
        }

    if (!db.isOpen() && !db.open()) {
        cout << "CWRTWebAppRegistry - Error  : !db.isOpen() && !db.open()"<< endl;
        return false;
        }

    QFileInfo dbFile(sqliteDbPath);
    if (dbFile.exists() && dbFile.size() == 0) {
        //create table as it does not exists
        db.exec("CREATE TABLE dbversion (version INTEGER)");
        QSqlError err = db.lastError();
        if(err.isValid()){
            cout << "CWRTWebAppRegistry - Error  : CREATE TABLE dbversion failed with error : "<<err.text().toAscii().data()<< endl;
            return false;
            }

        QString insertStatement;
        QTextStream(&insertStatement) << "INSERT INTO dbversion (version) VALUES (" << CurrentDatabaseVersion << ")";
        db.exec(insertStatement);
        err = db.lastError();
        if(err.isValid()){
            cout << "CWRTWebAppRegistry - Error  : INSERT INTO dbversion failed with error : "<<err.text().toAscii().data()<< endl;
            return false;
            }

        // NOTE for webapp_registry columns:  Per SQLite FAQ:  "SQLite does not enforce the length of a VARCHAR.
        //       You can declare a VARCHAR(10) and SQLite will be happy to let you put 500 characters in it. And
        //       it will keep all 500 characters intact - it never truncates."
        db.exec ("CREATE TABLE webapp_registry ( id VARCHAR(50) PRIMARY KEY, appTitle VARCHAR(100) NOT NULL, appPath VARCHAR(100) NOT NULL, iconPath VARCHAR, attributeList VARCHAR, secureSession VARCHAR, widgetType VARCHAR(20), uid INTEGER, startPath VARCHAR, dataPath VARCHAR(100) )");
        
        err = db.lastError();
        if(err.isValid()){
            cout << "CWRTWebAppRegistry - Error  : CREATE TABLE webapp_registry failed with error : "<<err.text().toAscii().data()<< endl;
            return false;
            }
        }
    return true;
}

bool registerApp(   const QString& dbPath,
                    const QString& appId,
                    int symbianUId,
                    const QString& appTitle,
                    const QString& appPath,
                    const QString& iconPath,
                    const QString& attributesList,
                    const QString& widgetType,
                    const QString& startPath)
{

    if (appId.isEmpty() || appTitle.isEmpty() || appPath.isEmpty()){
        cout << "CWRTWebAppRegistry - Error : appId.isEmpty() || appTitle.isEmpty() || appPath.isEmpty()" << endl;
        return false;
        }

    bool ret = create(dbPath);
    if(!ret)
        return ret;

    QSqlDatabase db = QSqlDatabase::database("webAppConnection");

    QString dataPath = appPath.section(QDir::separator(),0,2) + QDir::separator()+ QString(DATA_FOLDER)+ QDir::separator() + appPath.section(QDir::separator(),4);

    cout << "DATA PATH " <<dataPath.toLocal8Bit().constData()<<endl;
    
    if (!db.isOpen()) {
        cout << "CWRTWebAppRegistry - Error : appId.isEmpty() || appTitle.isEmpty() || appPath.isEmpty()" << endl;
        return false;
        }

    QSqlQuery query(db);
    query.prepare("INSERT INTO webapp_registry (id, appTitle, appPath, iconPath, attributeList, secureSession, widgetType, uid, startPath, dataPath) "
            "VALUES (:id, :appTitle, :appPath, :iconPath, :attributeList, :secureSession, :widgetType, :uid, :startPath, :dataPath)");
        
    query.bindValue(":id", QVariant (appId));
    query.bindValue(":appTitle", QVariant (appTitle));


    QString appPathNative = QDir::toNativeSeparators(appPath);
    // FIXME enforce canonicalization in caller
    // must end in QDir::separator()
    if (QDir::separator() != appPathNative.at(appPathNative.count()-1)) {
        appPathNative.append(QDir::separator());
        }

    query.bindValue(":appPath", QVariant (appPathNative));
    query.bindValue(":iconPath", QVariant (iconPath));

   /* QString attributesList;
    AttributeMap::const_iterator i;
    QString key;
    QString value;
    for (i=attributes.begin(); i != attributes.end(); i++) {
        key = i.key();
        value = i.value().toString();

        encodeDelimiters(key);
        encodeDelimiters(value);
        attributesList = attributesList + key +
            KEY_VALUE_SEPERATOR + value + KEY_VALUE_PAIR_SEPERATOR;
        }
    */
    query.bindValue(":attributeList", QVariant (attributesList));

    query.bindValue(":widgetType", QVariant (widgetType));
    query.bindValue(":startPath", QVariant (startPath));
    query.bindValue(":uid", symbianUId);
    query.bindValue(":dataPath", QVariant (dataPath));
    
    ret = query.exec();
    cout << "CWRTWebAppRegistry - Query : " <<query.executedQuery().toLocal8Bit().constData()<< endl;
    if(!ret){
        cout << "CWRTWebAppRegistry - Error : INSERT INTO webapp_registry failed" << endl;
        }
    db.close();
    return ret;
}


//CWRTWidgetDBRegister.exe dbname, appId, symbianAppId, appTitle, appPath, iconPath, widgetType, startPath


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    cout << "%%%%%%%%%%%%%%%%%%%%%%% CWRTWebAppRegistry %%%%%%%%%%%%%%%%%%%%%%%"<< endl;

    QStringList argsList = a.arguments();
    cout << "CWRTWebAppRegistry - Arguements to CWRTWidgetWebAppRegistry..."<< endl;
    for (int i = 0; i < argsList.size(); ++i)
    {
    		QString out = decodeDelimiters(argsList.at(i));
        cout << "CWRTWebAppRegistry : "<<out.toLocal8Bit().constData() << endl;
    }

	QString attrList;
	if(argsList.size() < 8)
    {
        cout << "CWRTWebAppRegistry - Error : args < 8" << endl;
        return false;
    }
    
    if(argsList.size() >= 10)
    {
      cout << "CWRTWebAppRegistry - :  args >= 10" << endl;
    	attrList = decodeDelimiters(argsList[9]);
    }


		bool ok(false);
		int uid = decodeDelimiters(argsList[3]).toInt(&ok);
		if(!ok){
			cout << "CWRTWebAppRegistry - UID doesnt seem to be an integer : "<<argsList[3].toLocal8Bit().constData()<< endl;
			return false;
			}
		
		
   // AttributeMap dummyMap;
    // Todo - populate parsed attribute map values into the list.

    bool ret = registerApp( decodeDelimiters(argsList[1]),        // db name with path
                        decodeDelimiters(argsList[2]),        // appId
                        decodeDelimiters(argsList[3]).toInt(),// SymbianAppUId
                        decodeDelimiters(argsList[4]),        // appTitle
                        decodeDelimiters(argsList[5]),        // appPath
                        decodeDelimiters(argsList[6]),        // iconPath
                        attrList,        											//AttributeList
                        decodeDelimiters(argsList[7]),        // widgetType
                        decodeDelimiters(argsList[8]));       // startPath

    cout << "%%%%%%%%%%%%%%%%%%%%%%% CWRTWebAppRegistry %%%%%%%%%%%%%%%%%%%%%%%"<< endl;
    return ret;
}
