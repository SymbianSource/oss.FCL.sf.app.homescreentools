Home Screen HSPluginPreInstaller - Commandline Version

Welcome to HSPluginPreInstaller! 

Home Screen HSPluginPreInstaller provides the ability to create template based Home screen native plugins for miniview presentations of Homescreen enabled WRT widgets by reading the widget registry. 

Installation Notes
 
 1. Just unzip the installation zip file and run HSPluginPreInstaller.bat.
 2. Ensure java.exe is on the path. Java must be of version 1.5 or above.
 3. Edit HSPluginPreInstaller.ini file and fill the right values for all mandatory attributes.
 4. Call hspluginpreinstaller.bat with the path appropriate for temporary files as a first parameter and the path to your case specific HSPluginPreInstaller.ini file as a second parameter. As an example:
 
hspluginpreinstaller.bat c:/temp HSPluginPreInstaller.ini

  