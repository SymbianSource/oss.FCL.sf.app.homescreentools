Home Screen HSPluginPreInstaller - Commandline Version

Welcome to HSPluginPreInstaller! 

Home Screen HSPluginPreInstaller provides the ability to create wrt plugins  by reading the widget registry. 

Installation Notes
 
 1. Just unzip the installation zip file and run HSPluginPreInstaller.bat.
 2. Ensure java.exe is on the path. Java must be of version 1.5 or above.
 3. Edit HSPluginPreInstaller.bat and point to your HSPluginPreInstaller.ini file
 4. Edit HSPluginPreInstaller.ini file and fill the right values for all mandatory attributes.
 
  